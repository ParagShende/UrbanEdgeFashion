document.addEventListener("DOMContentLoaded", function () {
    const addToCartButtons = document.querySelectorAll(".add-to-cart");

    addToCartButtons.forEach(button => {
        button.addEventListener("click", function () {
            let productName = document.querySelector("h1").innerText;
            let productPrice = document.querySelector(".price").innerText;
            let cart = JSON.parse(localStorage.getItem("cart")) || [];

            let product = {
                name: productName,
                price: productPrice
            };

            cart.push(product);
            localStorage.setItem("cart", JSON.stringify(cart));

            // Create success message
            let successMessage = document.createElement("div");
            successMessage.className = "success-message";
            successMessage.innerText = `${productName} added to cart successfully!`;
            document.querySelector(".actions").appendChild(successMessage);

            // Remove message after 3 seconds
            setTimeout(() => {
                successMessage.remove();
            }, 3000);
        });
    });
});
