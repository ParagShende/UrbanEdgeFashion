from flask import Flask, render_template, request, redirect, url_for, session
from flask import flash
import mysql.connector
db = mysql.connector.connect(
    host="localhost",
    user="root",  # Your MySQL username
    password="",  # Your MySQL password (leave empty if not set)
    database="project_database"  # Your database name in XAMPP
)
cursor = db.cursor()
app = Flask(__name__)
app.secret_key = 'your_secret_key'  # This is important for session management!

# Simulated user data (replace this with actual database logic later)
users = {"user@example.com": "password123", "paragshende8784@gmail.com": "parag8784","khushibawane2004@gamil.com":"parag8784"}

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def do_login():
    username = request.form['username']  # Match the HTML form's name attribute
    password = request.form['password']  # Match the HTML form's name attribute

    if username in users and users[username] == password:
        session['user'] = username  # Store user information in session
        return redirect(url_for('shopping'))  # Redirect to shopping page after successful login
    else:
        return "Invalid credentials, please try again."  # Display error message
@app.route('/signup')
def signup():
    return render_template('signup.html')
@app.route('/product/<product_id>')
def product_details(product_id):
    products = {
        "1": {"name": "Crew Neck Tee White Cotton T-shirt", "price": "₹299", "image": "static/images/product1.jpg"},
        "2": {"name": "Long Sleeve Deep Forest T-shirt", "price": "₹499", "image": "static/images/product2.jpg"},
        "3": {"name": "Peach Orange Crew Neck T-shirt", "price": "₹699", "image": "static/images/product3.jpg"},
        "4": {"name": "Charcoal Grey Cotton T-shirt", "price": "₹899", "image": "static/images/product4.jpg"},
        "5": {"name": "Stylish Indigo Blue Cotton T-shirt", "price": "₹299", "image": "static/images/product5.jpg"},
        "6": {"name": "Pure Black Man's Cotton T-shirt", "price": "₹199", "image": "static/images/product6.jpg"},
        "7": {"name": "Dark Blue Crew Neck T-shirt", "price": "₹249", "image": "static/images/product7.jpg"},
        "8": {"name": "Clove Pink Cotton T-shirt", "price": "₹449", "image": "static/images/product8.jpg"}
    }

    if product_id in products:
        product = products[product_id]
        return render_template('product_details.html', product=product)
    else:
        return "Product Not Found", 404
@app.route('/signup', methods=['POST'])
def do_signup():
    name = request.form['name']
    email = request.form['email']
    phone = request.form['phone']
    password = request.form['password']

    if email in users:
        ('Email Already Exists, Please Login!')
        return redirect(url_for('signup'))
    else:
        # Save user temporarily in dictionary
        users[email] = password
        ('Signup Successful! Please Login.')
        return redirect(url_for('login'))
@app.route('/product1')
def product1():
    if 'user' in session:
        return render_template('men/product1.html')
    else:
        return redirect(url_for('login'))
@app.route('/product2')
def product2():
    if 'user' in session:
        return render_template('men/product2.html')
    else:
        return redirect(url_for('login'))
@app.route('/product3')
def product3():
    if 'user' in session:
        return render_template('men/product3.html')
    else:
        return redirect(url_for('login'))
@app.route('/product4')
def product4():
    if 'user' in session:
        return render_template('men/product4.html')
    else:
        return redirect(url_for('login'))
@app.route('/product5')
def product5():
    if 'user' in session:
        return render_template('men/product5.html')
    else:
        return redirect(url_for('login'))
@app.route('/product6')
def product6():
    if 'user' in session:
        return render_template('men/product6.html')
    else:
        return redirect(url_for('login'))
@app.route('/product7')
def product7():
    if 'user' in session:
        return render_template('men/product7.html')
    else:
        return redirect(url_for('login'))
@app.route('/product8')
def product8():
    if 'user' in session:
        return render_template('men/product8.html')
    else:
        return redirect(url_for('login'))
@app.route('/women_product1')
def women_product1():
    if 'user' in session:
        return render_template('women/product1.html')
    else:
        return redirect(url_for('login'))
@app.route('/women_product2')
def women_product2():
    if 'user' in session:
        return render_template('women/product2.html')
    else:
        return redirect(url_for('login'))

@app.route('/women_product3')
def women_product3():
    if 'user' in session:
        return render_template('women/product3.html')
    else:
        return redirect(url_for('login'))

@app.route('/women_product4')
def women_product4():
    if 'user' in session:
        return render_template('women/product4.html')
    else:
        return redirect(url_for('login'))

@app.route('/women_product5')
def women_product5():
    if 'user' in session:
        return render_template('women/product5.html')
    else:
        return redirect(url_for('login'))

@app.route('/women_product6')
def women_product6():
    if 'user' in session:
        return render_template('women/product6.html')
    else:
        return redirect(url_for('login'))

@app.route('/women_product7')
def women_product7():
    if 'user' in session:
        return render_template('women/product7.html')
    else:
        return redirect(url_for('login'))

@app.route('/women_product8')
def women_product8():
    if 'user' in session:
        return render_template('women/product8.html')
    else:
        return redirect(url_for('login'))
@app.route('/kids_product1')
def kids_product1():
    if 'user' in session:
        return render_template('kids/product1.html')
    else:
        return redirect(url_for('login'))

@app.route('/kids_product2')
def kids_product2():
    if 'user' in session:
        return render_template('kids/product2.html')
    else:
        return redirect(url_for('login'))

@app.route('/kids_product3')
def kids_product3():
    if 'user' in session:
        return render_template('kids/product3.html')
    else:
        return redirect(url_for('login'))

@app.route('/kids_product4')
def kids_product4():
    if 'user' in session:
        return render_template('kids/product4.html')
    else:
        return redirect(url_for('login'))

@app.route('/kids_product5')
def kids_product5():
    if 'user' in session:
        return render_template('kids/product5.html')
    else:
        return redirect(url_for('login'))

@app.route('/kids_product6')
def kids_product6():
    if 'user' in session:
        return render_template('kids/product6.html')
    else:
        return redirect(url_for('login'))

@app.route('/kids_product7')
def kids_product7():
    if 'user' in session:
        return render_template('kids/product7.html')
    else:
        return redirect(url_for('login'))

@app.route('/kids_product8')
def kids_product8():
    if 'user' in session:
        return render_template('kids/product8.html')
    else:
        return redirect(url_for('login'))

@app.route('/shopping')
def shopping():
    if 'user' in session:  # Check if the user is logged in (session exists)
        return render_template('shopping.html')  # Show the shopping page
    else:
        return redirect(url_for('login'))  # If not logged in, redirect to login page
@app.route("/buy_now")
def buy_now():
    return render_template("buy_now.html")

@app.route("/confirm_order", methods=["POST"])
def confirm_order():
    if request.method == "POST":
        name = request.form["name"]
        surname = request.form["surname"]
        address1 = request.form["address1"]
        address2 = request.form["address2"]
        state = request.form["state"]
        city = request.form["city"]
        pincode = request.form["pincode"]
        mobile = request.form["mobile"]
        
        flash("Your order will be delivered to your desired location in 4-5 working days", "success")
        flash('Order Confirmed Successfully!', 'success')

        # Clear the cart session after successful purchase
        session['cart'] = {}  # Clear the cart items
        return redirect(url_for('cart'))
@app.route('/women')
def women():
    if 'user' in session:  # Check if the user is logged in
        return render_template('womens.html')  # Render the women's page
    else:
        return redirect(url_for('login'))  # Redirect to login page if not logged in

@app.route('/men')
def men():
    if 'user' in session:  # Check if the user is logged in
        return redirect(url_for('shopping'))  # Redirect to shopping.html
    else:
        return redirect(url_for('login'))  # Redirect to login page if not logged in
@app.route('/kids')
def kid():
    if 'user' in session:  # Check if the user is logged in
        return render_template('kids.html')  # Render the kids.html page
    else:
        return redirect(url_for('login')) 
@app.route('/help')
def help():
    if 'user' in session:  # Check if the user is logged in
        return render_template('help.html')  # Render the kids.html page
    else:
        return redirect(url_for('login')) 
@app.route('/about')
def about():
    if 'user' in session:  # Check if the user is logged in
        return render_template('about.html')  # Render the kids.html page
    else:
        return redirect(url_for('login')) 
@app.route('/cart')
def cart():
    if 'user' in session:  # Check if the user is logged in
        return render_template('cart.html')  # Render the kids.html page
    else:
        return redirect(url_for('login')) 
@app.route('/logout')
def logout():
    session.pop('user', None)  # Remove the session data to log the user out
    return redirect(url_for('login'))  # Redirect to the login page

if __name__ == '__main__':
    app.run(debug=True)
